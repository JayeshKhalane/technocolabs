var mongoose = require('mongoose');
var Schema = mongoose.Schema;

userSchema = new Schema( {
	
	unique_id: Number,
	Subject: String,
	Assign_Name: String,
	Status:String,
	Creted_Date:Date
	
}),
User = mongoose.model('User', userSchema);

module.exports = User;